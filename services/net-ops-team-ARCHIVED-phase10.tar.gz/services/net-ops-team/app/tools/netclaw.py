"""NetClaw integration — HTTP client for the NetClaw REST proxy.

The proxy runs inside the NetClaw container at http://netclaw:18790
and translates HTTP requests into `openclaw agent` CLI calls.
"""

import logging
import re

import httpx

from ..config import settings

logger = logging.getLogger(__name__)

# netclaw_url is http://netclaw:18789 — proxy is on :18790
_PROXY_URL = re.sub(r":\d+$", ":18790", settings.netclaw_url)


async def ask_netclaw(prompt: str, timeout: int = 120) -> dict:
    """Send a prompt to NetClaw via the REST proxy and return the response."""
    try:
        async with httpx.AsyncClient(timeout=timeout + 30) as client:
            resp = await client.post(
                f"{_PROXY_URL}/api/agent",
                json={"message": prompt, "timeout": timeout},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        return {"status": "error", "message": f"NetClaw timeout after {timeout}s"}
    except Exception as e:
        return {"status": "error", "message": f"NetClaw unavailable: {e}"}
